#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Telegram Bot主模块
"""
import os
import logging
import asyncio
from typing import List, Dict, Any
from datetime import datetime
from telegram import Update, Bot, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler
from telegram.ext import filters, ContextTypes
from app.models.database import connect_to_mongodb, close_mongodb_connection
from app.models.user import create_user, get_user, update_user
from app.models.message import save_message

logger = logging.getLogger(__name__)

# 从环境变量获取管理员ID
ADMIN_IDS = [int(admin_id.strip()) for admin_id in os.getenv("ADMIN_IDS", "").split(",") if admin_id.strip()]
# 自动删除消息配置
AUTO_DELETE_MESSAGES = os.getenv("AUTO_DELETE_MESSAGES", "true").lower() == "true"
AUTO_DELETE_INTERVAL = int(os.getenv("AUTO_DELETE_INTERVAL", 30))

async def setup_bot(token: str) -> Bot:
    """设置并启动Telegram Bot"""
    # 连接数据库
    await connect_to_mongodb()
    
    # 创建应用实例
    application = Application.builder().token(token).build()
    
    # 获取Bot实例
    bot = application.bot
    
    # 注册命令处理器
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("stats", stats_command))
    application.add_handler(CommandHandler("admin", admin_command))
    
    # 注册消息处理器
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    application.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    
    # 注册回调查询处理器
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    
    # 注册错误处理器
    application.add_error_handler(error_handler)
    
    # 启动Bot
    await application.initialize()
    await application.start()
    
    logger.info("Telegram Bot已启动")
    return bot

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理/start命令"""
    user = update.effective_user
    
    # 保存用户信息到数据库
    user_data = {
        "user_id": user.id,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "is_admin": user.id in ADMIN_IDS,
        "is_bot": user.is_bot,
        "language_code": user.language_code
    }
    await create_user(user_data)
    
    # 构建欢迎消息
    keyboard = [
        [
            InlineKeyboardButton("帮助", callback_data="help"),
            InlineKeyboardButton("统计", callback_data="stats")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = await update.message.reply_text(
        f"你好，{user.first_name}！欢迎使用Telegram Bot。\n"
        f"你可以使用 /help 命令获取帮助。",
        reply_markup=reply_markup
    )
    
    # 保存消息
    await save_message_to_db(update, "text", message.text)
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理/help命令"""
    help_text = (
        "以下是可用的命令：\n\n"
        "/start - 开始使用机器人\n"
        "/help - 显示帮助信息\n"
        "/stats - 显示统计信息\n"
    )
    
    # 如果是管理员，添加管理员命令
    user = update.effective_user
    if user.id in ADMIN_IDS:
        help_text += "\n管理员命令：\n/admin - 访问管理员功能\n"
    
    message = await update.message.reply_text(help_text)
    
    # 保存消息
    await save_message_to_db(update, "text", message.text)
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理/stats命令"""
    # 这里应该从数据库获取统计信息
    stats_text = "Bot统计信息：\n(这里将显示从数据库获取的统计数据)"
    
    message = await update.message.reply_text(stats_text)
    
    # 保存消息
    await save_message_to_db(update, "text", message.text)
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理/admin命令 - 仅管理员可用"""
    user = update.effective_user
    
    if user.id not in ADMIN_IDS:
        message = await update.message.reply_text("抱歉，只有管理员才能使用此命令。")
        # 自动删除消息
        if AUTO_DELETE_MESSAGES:
            await auto_delete_message(update.effective_chat.id, message.message_id)
        return
    
    # 构建管理菜单
    keyboard = [
        [
            InlineKeyboardButton("网页管理后台", url=f"http://{os.getenv('WEB_HOST', '0.0.0.0')}:{os.getenv('WEB_PORT', 7000)}")
        ],
        [
            InlineKeyboardButton("用户管理", callback_data="admin_users"),
            InlineKeyboardButton("消息管理", callback_data="admin_messages")
        ],
        [
            InlineKeyboardButton("设置", callback_data="admin_settings")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = await update.message.reply_text(
        "管理员控制面板：",
        reply_markup=reply_markup
    )
    
    # 保存消息
    await save_message_to_db(update, "text", message.text)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理文本消息"""
    # 更新用户活动状态
    user = update.effective_user
    await update_user(user.id, {"last_activity": datetime.now()})
    
    # 保存消息到数据库
    await save_message_to_db(update, "text", update.message.text)
    
    # 这里可以添加更多的消息处理逻辑
    # 例如，调用AI处理消息内容等
    
    # 简单的回复
    message = await update.message.reply_text(f"收到你的消息: {update.message.text}")
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理图片消息"""
    # 更新用户活动状态
    user = update.effective_user
    await update_user(user.id, {"last_activity": datetime.now()})
    
    # 获取图片信息
    photo = update.message.photo[-1]  # 获取最大尺寸的图片
    file_id = photo.file_id
    
    # 保存消息到数据库
    await save_message_to_db(update, "photo", None, file_id=file_id)
    
    # 回复消息
    message = await update.message.reply_text("收到你的图片")
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理文档消息"""
    # 更新用户活动状态
    user = update.effective_user
    await update_user(user.id, {"last_activity": datetime.now()})
    
    # 获取文档信息
    document = update.message.document
    file_id = document.file_id
    file_name = document.file_name
    
    # 保存消息到数据库
    await save_message_to_db(
        update, 
        "document", 
        None, 
        file_id=file_id, 
        content={"file_name": file_name}
    )
    
    # 回复消息
    message = await update.message.reply_text(f"收到你的文档: {file_name}")
    
    # 自动删除消息
    if AUTO_DELETE_MESSAGES:
        await auto_delete_message(update.effective_chat.id, message.message_id)

async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理按钮回调查询"""
    query = update.callback_query
    await query.answer()
    
    # 根据回调数据处理不同的操作
    if query.data == "help":
        await query.edit_message_text(text="这里是帮助信息...")
    elif query.data == "stats":
        await query.edit_message_text(text="这里是统计信息...")
    elif query.data.startswith("admin_"):
        # 处理管理员操作
        if query.from_user.id not in ADMIN_IDS:
            await query.edit_message_text(text="抱歉，只有管理员才能执行此操作。")
            return
        
        if query.data == "admin_users":
            await query.edit_message_text(text="用户管理功能...")
        elif query.data == "admin_messages":
            await query.edit_message_text(text="消息管理功能...")
        elif query.data == "admin_settings":
            await query.edit_message_text(text="设置功能...")

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """处理错误"""
    logger.error(f"更新 {update} 导致错误 {context.error}")

async def save_message_to_db(
    update: Update, 
    message_type: str, 
    text: str = None, 
    file_id: str = None, 
    content: Dict = None
) -> None:
    """保存消息到数据库"""
    try:
        message = update.message or update.edited_message
        if not message:
            return
        
        # 准备消息数据
        message_data = {
            "message_id": message.message_id,
            "chat_id": message.chat_id,
            "user_id": message.from_user.id,
            "text": text or message.text,
            "date": datetime.now(),  # 使用服务器时间
            "message_type": message_type,
            "file_id": file_id,
            "content": content or {}
        }
        
        # 如果是回复消息，添加回复信息
        if message.reply_to_message:
            message_data["reply_to_message_id"] = message.reply_to_message.message_id
        
        # 保存消息
        await save_message(message_data)
    except Exception as e:
        logger.error(f"保存消息到数据库时出错: {e}")

async def auto_delete_message(chat_id: int, message_id: int) -> None:
    """自动删除消息"""
    if not AUTO_DELETE_MESSAGES:
        return
    
    try:
        # 等待指定时间后删除消息
        await asyncio.sleep(AUTO_DELETE_INTERVAL)
        # 删除消息
        await Application.get_instance().bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception as e:
        logger.error(f"自动删除消息时出错: {e}") 