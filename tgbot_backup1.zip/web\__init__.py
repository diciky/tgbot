#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Web管理界面包
"""