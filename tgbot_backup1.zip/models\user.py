#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
用户模型
"""
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field
from .database import get_collection, USERS_COLLECTION

logger = logging.getLogger(__name__)

class User(BaseModel):
    """用户模型"""
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    is_admin: bool = False
    is_bot: bool = False
    language_code: Optional[str] = None
    join_date: datetime = Field(default_factory=datetime.now)
    last_activity: datetime = Field(default_factory=datetime.now)
    groups: List[int] = Field(default_factory=list)
    settings: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        """Pydantic配置"""
        validate_assignment = True
        arbitrary_types_allowed = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

async def get_user(user_id: int) -> Optional[Dict[str, Any]]:
    """获取用户信息"""
    collection = get_collection(USERS_COLLECTION)
    user = await collection.find_one({"user_id": user_id})
    return user

async def create_user(user_data: Dict[str, Any]) -> Dict[str, Any]:
    """创建用户"""
    collection = get_collection(USERS_COLLECTION)
    
    # 检查用户是否已存在
    existing_user = await get_user(user_data["user_id"])
    if existing_user:
        return existing_user
    
    # 设置创建时间
    user_data["join_date"] = datetime.now()
    user_data["last_activity"] = datetime.now()
    
    # 创建用户
    result = await collection.insert_one(user_data)
    if result.inserted_id:
        return await get_user(user_data["user_id"])
    return None

async def update_user(user_id: int, update_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """更新用户信息"""
    collection = get_collection(USERS_COLLECTION)
    
    # 更新用户活动时间
    update_data["last_activity"] = datetime.now()
    
    result = await collection.update_one(
        {"user_id": user_id},
        {"$set": update_data}
    )
    
    if result.modified_count > 0 or result.matched_count > 0:
        return await get_user(user_id)
    return None

async def get_all_users(limit: int = 100, skip: int = 0) -> List[Dict[str, Any]]:
    """获取所有用户"""
    collection = get_collection(USERS_COLLECTION)
    cursor = collection.find().skip(skip).limit(limit)
    return await cursor.to_list(length=limit)

async def get_admins() -> List[Dict[str, Any]]:
    """获取所有管理员用户"""
    collection = get_collection(USERS_COLLECTION)
    cursor = collection.find({"is_admin": True})
    return await cursor.to_list(length=100)

async def count_users() -> int:
    """统计用户数量"""
    collection = get_collection(USERS_COLLECTION)
    return await collection.count_documents({})

async def delete_user(user_id: int) -> bool:
    """删除用户"""
    collection = get_collection(USERS_COLLECTION)
    result = await collection.delete_one({"user_id": user_id})
    return result.deleted_count > 0 