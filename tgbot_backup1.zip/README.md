# Telegram Bot 管理系统

一个集成Web管理界面的Telegram Bot应用，可以通过Web界面管理Telegram机器人。

## 功能特点

- Telegram Bot功能
  - 处理文本、图片、文档等消息
  - 自动保存消息记录
  - 支持自动删除消息
  - 管理员命令支持

- Web管理界面
  - 用户管理
  - 消息查看与发送
  - 实时统计
  - 响应式设计

## 技术栈

- Python 3.11
- python-telegram-bot
- FastAPI
- MongoDB
- Bootstrap 5
- Docker & Docker Compose

## 安装与部署

### 环境要求

- Docker & Docker Compose
- 有效的Telegram Bot Token

### 使用Docker部署

1. 克隆代码库

```bash
git clone https://github.com/your-username/tgbot.git
cd tgbot
```

2. 配置环境变量

修改`.env`文件，设置必要的环境变量：

```
# Telegram Bot配置
BOT_TOKEN=your_bot_token
ADMIN_IDS=your_admin_id  # 管理员ID，用逗号分隔

# MongoDB配置
MONGO_USERNAME=admin
MONGO_PASSWORD=your_password
MONGO_DB=tgbot

# Web配置
WEB_PORT=7000
WEB_HOST=0.0.0.0
SECRET_KEY=your_secret_key
ADMIN_USERNAME=admin
ADMIN_PASSWORD=admin
```

3. 启动服务

```bash
docker-compose up -d
```

服务将在后台启动，Web管理界面将在 `http://localhost:7000` 提供访问。

### 开发环境设置

1. 创建虚拟环境

```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows
```

2. 安装依赖

```bash
pip install -r requirements.txt
```

3. 运行应用

```bash
python main.py
```

## 使用说明

### 管理员登录

访问 `http://your-server:7000/login` 并使用以下默认凭据登录：
- 用户名：admin
- 密码：admin

建议登录后立即修改默认密码。

### 基本功能

- **仪表盘**：显示系统概览和关键统计数据
- **用户管理**：查看和管理Bot用户
- **消息管理**：查看和发送消息
- **设置**：配置Bot和系统参数

## 安全注意事项

- 部署到生产环境前请修改所有默认密码
- 建议使用HTTPS保护Web管理界面
- 定期备份数据库

## 许可证

MIT 