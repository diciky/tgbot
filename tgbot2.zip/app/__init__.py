"""
Telegram Bot应用初始化
""" 